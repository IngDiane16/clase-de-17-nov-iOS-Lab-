//: Playground - noun: a place where people can play

import Cocoa

var str = "Hello, playground"
var name: String = "Pedro"
var age = 22
var latitude = -89.2345
type(of : latitude)
 "your name is " + name
"your name is \(name) your age in \(age) will be \(age*2)"
var someInt = [Int]()
print(someInt.count)
someInt.append(3)
someInt = []
var someValues  = Array(repeating : 0.0, count: 3)
var otherValues  = Array(repeating : 2.5, count: 3)
otherValues += Array(repeating : 5.0, count: 3)

//sumando los dos arreglos anteriores
someValues + otherValues

//para ver de qué tipo son tus valores
type(of: someValues)

//Se puede declarar un arreglo para poder ingresar cualquier tipo de valores
var arrayAnyType : [Any] = ["Hello", true, 2,2.5]

//un tupla es inmutable

//CReando una lista de compras

var shoppingList: [String] = ["Eggs", "Milk"]

//para saber si nuestro arreglo está vacío

if shoppingList.isEmpty{
    print("The shopping list is empty")
}else{
    print("The shopping list is not empty")
    
}
shoppingList.append("flour")
shoppingList += ["Baking powder"]
shoppingList += ["Chocolate spread", "Cheese", "Butter"]

//En un append no puedes agregar más de un elemento

//si yo quiero agregar un argumento a otra variable, realizar lo siguiente
//declarar el arreglo, en los corchetes poner la posicion del elemento
var chocolate = shoppingList[4]

//Para modificar un elemento del arreglo:

shoppingList[0] = "six eggs"

//comprobando lo que tenemos
print(shoppingList)

//cambiar de la posición cuatro a la seis
shoppingList[4...6] = ["Bananas", "Apples", "Mangos"]
print(shoppingList)

//Para insertar un elemento en una posiciòn en específico ocupar la propiedad "insert", inserta en la posición el elemento que deseas y el resto lo recorre

shoppingList.insert("Maple Syrup", at: 2)

//para quitar un elemento se utiliza .remove

//shoppingList.remove(at: 2)

//para quitar un elemento y ese elemento lo asigna a una variable
var maple = shoppingList.remove(at: 2)

//para remover el ùltimo elemento se utiliza .removeLast()
 let apples =  shoppingList.removeLast()

//para imprimir todos los items de un arreglo se usa un for
for item in shoppingList{
    print(item)
}
//enumerated
for (index, value) in shoppingList.enumerated() {
    print("item \(index+1): \(value)")
}

//Diccionarios, una lista de elementos, cada elemento(no tienen que ser necesariamente ordenado) tiene una llave(ordenadas)
//var nameOfIntegers = [Llave:String]()

var nameOfIntegers = [Int:String]()
nameOfIntegers[16] = "sixteen" //En la llave dieciseis vas a tener el valor "sixteen"
type(of: nameOfIntegers)

//Creando variable aeropuertos
var airports = ["YYZ":"Toronto Pearson","DUB":"Dublin"]

type(of: airports)
airports.count
if airports.isEmpty{
    print("The Dictionary is Empty")
}else{
    print("the dictionary is not Empty")
}
airports["LHR"] = "london"
airports["LHR"] = "London Heathrow"
airports.updateValue("Dublin Airport", forKey: "DUB")
airports.removeValue(forKey: "DUB")

for (airportCode, airportName) in airports{
    print("\(airportCode):\(airportName)")
}
//Para sacar los valores
var airportsNames = [String](airports.values)
//Para sacar las llaves
var airporsCodes = [String](airports.keys)

//-----conjuntos------------
var letters = Set<Character>()
letters.insert("A")
letters.insert("A")

var favoriteGenres: Set = ["Rock", "Classical", "Hip Hop"]

if favoriteGenres.isEmpty {
    print("Is Empty")
}else{
    print("is not empty")
}

var removeGenres = favoriteGenres.remove("Rock")

if favoriteGenres.contains("Funk"){
    print("yes")
}else{
    print("no")
}

var oddDigits: Set = [1,3,5,7,9]

var evenDigits: Set = [0,2,4,6,8]

var otherDigits: Set = [2,3,5,7]
//PARA hacer la uniòn de los dos primeros conjuntos
//.sorted ordena los datos de menor a mayor
oddDigits.union(evenDigits).sorted()

//para la intersecciòn
oddDigits.intersection(evenDigits).sorted()
evenDigits.intersection(otherDigits).sorted()

//La sustracciòn de oddDigits y otherDigits
oddDigits.subtracting(otherDigits).sorted()


//Para la simetria
oddDigits.symmetricDifference(otherDigits).sorted()

//Super conjunto
let houseAnimals: Set = ["🐶","🐱"]
let farmAnimals: Set = ["🐄","🐓","🐱","🐶"]
let CityAnimals: Set = ["🐦","🐭"]
//se pregunta si es un subconjunto
houseAnimals.isSubset(of: farmAnimals)

farmAnimals.isSuperset(of: houseAnimals)
//Si son dos conjuntos son completamente distintos
houseAnimals.isDisjoint(with: CityAnimals)
//tuplas, no pueden cambiar, siempre con let porque deben de ser constantes, paréntesis en lugar de corchetes, están ordenados al igual que un arreglo
let tuple = ("Diana", 21,"Mexico")
print("Hello my name is \(tuple.0) my age is \(tuple.1) and my country is \(tuple.2)")

//asigna a una variable la tupla
var (name1, age1, country) = tuple
print(name1)














